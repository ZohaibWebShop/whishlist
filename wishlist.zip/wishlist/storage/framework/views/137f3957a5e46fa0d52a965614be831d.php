<?php $__env->startSection('content'); ?>
    <div class="flex-center position-ref full-height">
        <div class="content">
            <div class="title m-b-md">Oops!</div>
                <p><?php echo e($message); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shopify-app::layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\data\wishlist\resources\views\vendor\shopify-app\billing\error.blade.php ENDPATH**/ ?>
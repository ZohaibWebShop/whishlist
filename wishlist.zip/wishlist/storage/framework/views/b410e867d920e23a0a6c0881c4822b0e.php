<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <base target="_top">

        <title>Redirecting...</title>
        <script src="https://unpkg.com/@shopify/app-bridge<?php echo e(\Osiset\ShopifyApp\Util::getShopifyConfig('appbridge_version') ? '@'.config('shopify-app.appbridge_version') : ''); ?>"></script>
        <script type="text/javascript">
            const redirectUrl = "<?php echo $url; ?>";

            const AppBridge = window['app-bridge'];
            const createApp = AppBridge.default;
            const Redirect = AppBridge.actions.Redirect;
            const app = createApp({
                apiKey: "<?php echo e($apiKey); ?>",
                host: "<?php echo e($host); ?>",
            });

            console.log( 'app', app );

            const redirect = Redirect.create(app);
            redirect.dispatch(Redirect.Action.REMOTE, redirectUrl);
        </script>
    </head>
    <body>
    </body>
</html>
<?php /**PATH C:\data\wishlist\resources\views\vendor\shopify-app\billing\fullpage_redirect.blade.php ENDPATH**/ ?>